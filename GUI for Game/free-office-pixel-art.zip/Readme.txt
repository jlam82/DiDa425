Thank you for your support!
I hope that helps you!

Free to use any way you want.

My page on itch.io. There you will find more assets made by me.
https://arlantr.itch.io/


More free game assets:
https://opengameart.org/users/arlantr
